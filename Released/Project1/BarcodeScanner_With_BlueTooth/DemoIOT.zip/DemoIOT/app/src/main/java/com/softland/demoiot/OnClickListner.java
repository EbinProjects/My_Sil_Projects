package com.softland.demoiot;

public interface OnClickListner {

     void onClick(int position,String deviceName,String deviceId);
}
