package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterCustomerRequestDataV2 {
    @SerializedName("Username")
    @Expose
    private String username;
    @SerializedName("CustomerName")
    @Expose
    private String customerName;
    @SerializedName("Password")
    @Expose
    private String password;
    @SerializedName("PhoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("ReferralCode")
    @Expose
    private String referralCode;
    @SerializedName("Address")
    @Expose
    private String address;
    @SerializedName("shortCode")
    @Expose
    private String shortCode;

    public RegisterCustomerRequestDataV2(String username, String customerName, String password, String phoneNumber,
                                         String referralCode, String address, String shortCode) {
        this.username = username;
        this.customerName = customerName;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.referralCode = referralCode;
        this.address= address;
        this.shortCode = shortCode ;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getReferralCode() {
        return referralCode;
    }

    public void setReferralCode(String referralCode) {
        this.referralCode = referralCode;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }
}
