package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterCustomerResponseV2 {
    @SerializedName("StatusReturn")
    @Expose
    private RegisterCustomerStatusReturnV2 registerCustomerStatusReturnV2;
    @SerializedName("ResponseData")
    @Expose
    private RegisterCustomerResponseDataV2 registerCustomerResponseDataV2;

    public RegisterCustomerResponseV2(RegisterCustomerStatusReturnV2 registerCustomerStatusReturnV2,
                                      RegisterCustomerResponseDataV2 registerCustomerResponseDataV2) {
        this.registerCustomerStatusReturnV2 = registerCustomerStatusReturnV2;
        this.registerCustomerResponseDataV2 = registerCustomerResponseDataV2;
    }

    public RegisterCustomerStatusReturnV2 getRegisterCustomerStatusReturnV2() {
        return registerCustomerStatusReturnV2;
    }

    public void setRegisterCustomerStatusReturnV2(RegisterCustomerStatusReturnV2 registerCustomerStatusReturnV2) {
        this.registerCustomerStatusReturnV2 = registerCustomerStatusReturnV2;
    }

    public RegisterCustomerResponseDataV2 getRegisterCustomerResponseDataV2() {
        return registerCustomerResponseDataV2;
    }

    public void setRegisterCustomerResponseDataV2(RegisterCustomerResponseDataV2 registerCustomerResponseDataV2) {
        this.registerCustomerResponseDataV2 = registerCustomerResponseDataV2;
    }
}

