package com.softland.demo.Model;

import android.util.Patterns;

public class LoginCustomer {
    private String strUsername;
    private String strPassword;

    public LoginCustomer(String username, String password) {
        strUsername = username;
        strPassword = password;
    }

    public String getStrEmailAddress() {
        return strUsername;
    }

    public String getStrPassword() {
        return strPassword;
    }

    public boolean isEmailValid() {
        return Patterns.EMAIL_ADDRESS.matcher(getStrEmailAddress()).matches();
    }


    public boolean isPasswordLengthGreaterThan10() {
        return getStrPassword().length() >10;
    }

}



