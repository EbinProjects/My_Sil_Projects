package com.softland.demo.UI;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.softland.demo.Annotations.ServiceNames;
import com.softland.demo.Annotations.ServiceResponseStatus;
import com.softland.demo.Interfaces.APIInterface;
import com.softland.demo.Interfaces.RetrofitApi;
import com.softland.demo.R;
import com.softland.demo.RetrofitModels.Credentials;
import com.softland.demo.RetrofitModels.RegisterCustomerRequestDataV2;
import com.softland.demo.RetrofitModels.RegisterCustomerRequestV2;
import com.softland.demo.RetrofitModels.RegisterCustomerResponseV2;
import com.softland.demo.Utils.FileUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SignUp extends AppCompatActivity {

    Button btnSignUp;
    EditText etUsername,etCustomerName,etPassword,etPhoneNumber,etShortCode,etReferralCode;
    TextView tLog;
    APIInterface authenticationInterface;
    ProgressDialog progressDialog;
    private static final String TAG = "MainActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        etUsername=(EditText)findViewById(R.id.edText1);
        etCustomerName=(EditText)findViewById(R.id.edText2);
        etPassword=(EditText)findViewById(R.id.edText3);
        etPhoneNumber=(EditText)findViewById(R.id.edText4);
        etShortCode=(EditText)findViewById(R.id.edText5);
        etReferralCode=(EditText)findViewById(R.id.edText6);
        btnSignUp=(Button)findViewById(R.id.SignupId);
        tLog=(TextView)findViewById(R.id.logg);

        tLog.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SignUp.this, MainActivity.class);
                startActivity(intent);


            }
        });

        btnSignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();
                String customerName=etCustomerName.getText().toString();
                String phoneNumber=etPhoneNumber.getText().toString();
                String shortCode=etShortCode.getText().toString();
                String referralCode=etReferralCode.getText().toString();

                if (validateLogin(username,customerName,password,phoneNumber,shortCode,referralCode)){
                    registerCustomerV2(username,customerName,password,phoneNumber,referralCode,"rigga",shortCode);
                }

            }
        });

    }
    private boolean validateLogin( String username, String customerName, String password, String phoneNumber, String shortCode,String referralCode) {
        if (username == null || username.trim().length() == 0) {
            Toast.makeText(this, "Username is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (customerName == null || customerName.trim().length() == 0) {
            Toast.makeText(this, "Customer Name is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password == null || password.trim().length() == 0) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (phoneNumber == null || phoneNumber.trim().length() == 0) {
            Toast.makeText(this, "Phone Number is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (shortCode == null || shortCode.trim().length() == 0) {
            Toast.makeText(this, "shortCode is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (referralCode == null || referralCode.trim().length() == 0) {
            Toast.makeText(this, "ReferralCode is required", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

public void registerCustomerV2(String username, String customerName, String password, String phoneNumber,
                             String referralCode, String address, String shortCode) {

    if (authenticationInterface == null) {
        String baseUrl = "http://202.88.237.210/RMS%20BYKYCUST_API_AUTHENTICATION/api/AuthenticationController/";
        authenticationInterface = RetrofitApi.getAuthClient(baseUrl).create(APIInterface.class);
    }

    Credentials credentials = new Credentials("0.0","0.0","0.0","bf164207d1fe9031","-1"  ,"1.0.38","android : 11 : R :","AC2001",
            0,"RegisterCustomerV2","0000","",0,0,0,"");

    RegisterCustomerRequestDataV2 registerCustomerRequestDataV2 = new RegisterCustomerRequestDataV2(username,customerName,password,phoneNumber,referralCode,address,shortCode);
    RegisterCustomerRequestV2 registerCustomerRequestV2 = new RegisterCustomerRequestV2(credentials,registerCustomerRequestDataV2);

    Log.e(TAG, "calling api loginCustomer.");
    FileUtils.showSendData(authenticationInterface.registerCustomerV2(registerCustomerRequestV2).request().url().toString(), ServiceNames.REGISTER_CUSTOMER_V2);
    FileUtils.showSendData(registerCustomerRequestV2, ServiceNames.REGISTER_CUSTOMER_V2);

    Call<RegisterCustomerResponseV2>registerCustomerResponseV2Call= authenticationInterface.registerCustomerV2(registerCustomerRequestV2);
    registerCustomerResponseV2Call.enqueue(new Callback<RegisterCustomerResponseV2>() {
        @Override
        public void onResponse(Call<RegisterCustomerResponseV2> call, Response<RegisterCustomerResponseV2> response) {


            try {
                FileUtils.showResponseData(response.body()
                        , ServiceNames.REGISTER_CUSTOMER_V2);
                if (response.body().getRegisterCustomerStatusReturnV2() != null) {
                    Log.e(TAG, "registerCustomer, api calling is success: " +
                            response.body().getRegisterCustomerStatusReturnV2().getStatus());

                    if (response.body().getRegisterCustomerResponseDataV2().getRetStatus()
                            .equals(ServiceResponseStatus.SUCCESS_CODE)) {

                        Toast.makeText(SignUp.this, response.body().getRegisterCustomerStatusReturnV2().getMessage(), Toast.LENGTH_SHORT).show();


                        progressDialog=new ProgressDialog(SignUp.this);
                        progressDialog.show();
                        progressDialog.setContentView(R.layout.progress_dialog);
                        progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);

                         Intent intent = new Intent(SignUp.this, MainActivity.class);
                        startActivity(intent);




                    } else {
                        Toast.makeText(SignUp.this, response.body().getRegisterCustomerResponseDataV2().getMessage(), Toast.LENGTH_SHORT).show();
                    }

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        public void onFailure(Call<RegisterCustomerResponseV2> call, Throwable t) {
                        Log.e(TAG, "loginCustomer, api calling is failed: " + t.getMessage());
                        FileUtils.showErrorData(t.getMessage(), ServiceNames.REGISTER_CUSTOMER_V2);


        }
    });



}}