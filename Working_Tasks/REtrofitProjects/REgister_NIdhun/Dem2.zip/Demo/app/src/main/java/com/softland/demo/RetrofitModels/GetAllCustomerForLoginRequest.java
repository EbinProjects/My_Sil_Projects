package com.softland.demo.RetrofitModels;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class GetAllCustomerForLoginRequest {

    @SerializedName("Credentials")
    @Expose
    private Credentials credentials;
    @SerializedName("RequestData")
    @Expose
    private GetAllCustomerForLoginRequestData getAllCustomerForLoginRequestData;

    /**
     * No args constructor for use in serialization
     */
    public GetAllCustomerForLoginRequest() {
    }

    public GetAllCustomerForLoginRequest(Credentials credentials, GetAllCustomerForLoginRequestData getAllCustomerForLoginRequestData) {
        this.credentials = credentials;
        this.getAllCustomerForLoginRequestData = getAllCustomerForLoginRequestData;
    }

    public Credentials getCredentials() {
        return credentials;
    }

    public void setCredentials(Credentials credentials) {
        this.credentials = credentials;
    }

    public GetAllCustomerForLoginRequestData getGetAllCustomerForLoginRequestData() {
        return getAllCustomerForLoginRequestData;
    }

    public void setGetAllCustomerForLoginRequestData(GetAllCustomerForLoginRequestData getAllCustomerForLoginRequestData) {
        this.getAllCustomerForLoginRequestData = getAllCustomerForLoginRequestData;
    }
}
