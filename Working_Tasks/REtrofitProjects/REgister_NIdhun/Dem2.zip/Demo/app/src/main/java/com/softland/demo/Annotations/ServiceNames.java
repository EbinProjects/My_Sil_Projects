package com.softland.demo.Annotations;

public @interface ServiceNames {
    String LOGIN_CUSTOMER_V2 = "LoginCustomerV2";
    String GET_ALL_CUSTOMER_FOR_LOGIN="GetAllCustomerForLogin";
    String REGISTER_CUSTOMER_V2= "RegisterCustomerV2";
}
