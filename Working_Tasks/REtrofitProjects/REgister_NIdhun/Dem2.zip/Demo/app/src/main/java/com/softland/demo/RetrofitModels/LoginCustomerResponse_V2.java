

package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginCustomerResponse_V2 {


    @SerializedName("StatusReturn")
    @Expose
    private LoginCustomerStatusReturn_V2 loginCustomerStatusReturnV2;
    @SerializedName("ResponseData")
    @Expose
    private LoginCustomerResponseData_V2 loginCustomerResponseDataV2;


    public LoginCustomerResponse_V2() {
    }

    public LoginCustomerResponse_V2(LoginCustomerStatusReturn_V2 loginCustomerStatusReturnV2
                                  , LoginCustomerResponseData_V2 loginCustomerResponseDataV2) {

        this.loginCustomerStatusReturnV2 = loginCustomerStatusReturnV2;
        this.loginCustomerResponseDataV2 = loginCustomerResponseDataV2;
    }

    public LoginCustomerStatusReturn_V2 getLoginCustomerStatusReturnV2() {
        return loginCustomerStatusReturnV2;
    }

    public void setLoginCustomerStatusReturnV2(LoginCustomerStatusReturn_V2 loginCustomerStatusReturnV2) {
        this.loginCustomerStatusReturnV2 = loginCustomerStatusReturnV2;
    }

    public LoginCustomerResponseData_V2 getLoginCustomerResponseDataV2() {
        return loginCustomerResponseDataV2;
    }

    public void setLoginCustomerResponseDataV2(LoginCustomerResponseData_V2 loginCustomerResponseDataV2) {
        this.loginCustomerResponseDataV2 = loginCustomerResponseDataV2;
    }
}

