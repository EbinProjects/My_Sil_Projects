package com.softland.demo.UI;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import com.softland.demo.R;

public class FirstPage extends AppCompatActivity {

        TextView txt,txt1,txt2,txt3;
        Toolbar toolbar;




        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView( R.layout.first);

            txt = (TextView) findViewById(R.id.textView);
            txt1=(TextView)findViewById(R.id.textView1);
            txt2=(TextView)findViewById(R.id.textView2);
            txt3=(TextView)findViewById(R.id.textView3);


           toolbar=findViewById(R.id.toolbar);

           setSupportActionBar(toolbar);



            String message=getIntent().getStringExtra("message");
            txt.setText(message);

            String customerName = getIntent().getStringExtra("name");
            txt1.setText(customerName);

            Integer ZoneID=getIntent().getIntExtra("ZoneID",0);
            txt2.setText(""+ZoneID);

            String phoneNumber=getIntent().getStringExtra("PhoneNumber");
            txt3.setText(phoneNumber);


        }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
         getMenuInflater().inflate(R.menu.menu,menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.settinsid) {
            Toast.makeText(FirstPage.this, "You clicked Settings", Toast.LENGTH_SHORT).show();

        }
        if (id == R.id.logoutid) {
            Toast.makeText(FirstPage.this, "You clicked Logout", Toast.LENGTH_SHORT).show();
            Intent intent=new Intent(FirstPage.this, SignUp.class);
            startActivity(intent);

        }

        return true;
    }
}


