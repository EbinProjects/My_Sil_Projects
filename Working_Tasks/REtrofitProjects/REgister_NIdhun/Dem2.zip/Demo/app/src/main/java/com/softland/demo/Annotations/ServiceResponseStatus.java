package com.softland.demo.Annotations;

public @interface ServiceResponseStatus {

    String SUCCESS = "SUCCESS";
    String ERROR = "ERROR";
    String CONNECTION_FAILED = "404";
    int ERROR_CODE = 0;
    int SUCCESS_CODE = 1;
    int INVALID_TOKEN_CODE = 2;
    int CONNECTION_FAILED_CODE = 404;
}
