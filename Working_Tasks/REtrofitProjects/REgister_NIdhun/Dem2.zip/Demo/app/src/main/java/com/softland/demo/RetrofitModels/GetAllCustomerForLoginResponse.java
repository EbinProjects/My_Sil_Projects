package com.softland.demo.RetrofitModels;


import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

public class GetAllCustomerForLoginResponse {

    @SerializedName("StatusReturn")
    @Expose
    private StatusReturn statusReturn;
    @SerializedName("ResponseData")
    @Expose
    private List<GetAllCustomerForLoginResponseData> getAllCustomerForLoginResponseData;

    public GetAllCustomerForLoginResponse() {

    }

    public StatusReturn getStatusReturn() {
        return statusReturn;
    }

    public void setStatusReturn(StatusReturn statusReturn) {
        this.statusReturn = statusReturn;
    }

    public List<GetAllCustomerForLoginResponseData> getGetAllCustomerForLoginResponseData() {
        return getAllCustomerForLoginResponseData;
    }

    public void setGetAllCustomerForLoginResponseData(List<GetAllCustomerForLoginResponseData> getAllCustomerForLoginResponseData) {
        this.getAllCustomerForLoginResponseData = getAllCustomerForLoginResponseData;
    }
}