package com.softland.demo.Model;

public class RegisterCustomer {

}
