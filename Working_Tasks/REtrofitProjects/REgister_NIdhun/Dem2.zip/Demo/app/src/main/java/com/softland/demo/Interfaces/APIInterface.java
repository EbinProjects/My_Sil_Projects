package com.softland.demo.Interfaces;

import com.softland.demo.Annotations.ServiceNames;
import com.softland.demo.RetrofitModels.GetAllCustomerForLoginRequest;
import com.softland.demo.RetrofitModels.GetAllCustomerForLoginResponse;
import com.softland.demo.RetrofitModels.LoginCustomerRequest_V2;
import com.softland.demo.RetrofitModels.LoginCustomerResponse_V2;
import com.softland.demo.RetrofitModels.RegisterCustomerRequestV2;
import com.softland.demo.RetrofitModels.RegisterCustomerResponseV2;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.POST;

/**
 * add all service calls here
 *
 * @POST(COMPANY_LOGO_REQUEST) //(@POST(END URL Address))
 * @POST send large amount of data ,more securue, encryption supported
 * @GET send small amount of data ,less securue
 * <p>
 * Call<CompanyLogoResponse> getCompanyLogo(@Body CompanyLogoRequest companyLogoRequest);
 * Call <POJO Class for get response from webservice> methodForCallWebService(@Body POJO Class for sending data to webservice)
 */
public interface APIInterface {


    String SOCIAL_MEDIA_REQUEST = "j2-webservice/index.php?fn=SocialMedia&Details=";
    String ONE_TIME_OFFER_REQUEST = "j2-webservice/index.php?fn=OneTimeOffer&Details=";




    @POST(ServiceNames.LOGIN_CUSTOMER_V2)
    Call<LoginCustomerResponse_V2> loginCustomerV2(
            @Body LoginCustomerRequest_V2 loginCustomerRequestV2);

    @POST(ServiceNames.GET_ALL_CUSTOMER_FOR_LOGIN)
    Call<GetAllCustomerForLoginResponse>getAllCustomerForLogin(
            @Body GetAllCustomerForLoginRequest getAllCustomerForLoginRequestData);

    @POST(ServiceNames.REGISTER_CUSTOMER_V2)
    Call<RegisterCustomerResponseV2>registerCustomerV2(
            @Body RegisterCustomerRequestV2 registerCustomerRequestV2);

}

