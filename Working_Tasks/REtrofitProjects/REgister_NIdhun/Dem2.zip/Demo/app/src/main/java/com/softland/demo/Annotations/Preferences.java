package com.softland.demo.Annotations;

public @interface Preferences {
    String CUSTOMER_PREFERENCE = "CustomerPreference";
    String SETTINGS_PREFERENCE = "SettingsPreference";
    String API_PREFERENCE = "ApiPreference";
    String APP_PREFERENCE = "AppPreference";
}
