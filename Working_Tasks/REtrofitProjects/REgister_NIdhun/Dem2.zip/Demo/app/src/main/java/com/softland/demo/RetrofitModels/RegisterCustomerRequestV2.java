package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
import com.softland.demo.RetrofitModels.Credentials;
import com.softland.demo.RetrofitModels.RegisterCustomerRequestDataV2;

public class RegisterCustomerRequestV2 {

    @SerializedName("Credentials")
    @Expose
    private Credentials credentials;
    @SerializedName("RequestData")
    @Expose
    private RegisterCustomerRequestDataV2 registerCustomerRequestDataV2;

    public RegisterCustomerRequestV2(Credentials credentials, RegisterCustomerRequestDataV2 registerCustomerRequestDataV2) {
        this.credentials = credentials;
        this.registerCustomerRequestDataV2 = registerCustomerRequestDataV2;
    }

    public Credentials getCredentials() {
        return credentials;
    }

    public void setCredentials(Credentials credentials) {
        this.credentials = credentials;
    }

    public RegisterCustomerRequestDataV2 getRegisterCustomerRequestDataV2() {
        return registerCustomerRequestDataV2;
    }

    public void setRegisterCustomerRequestDataV2(RegisterCustomerRequestDataV2 registerCustomerRequestDataV2) {
        this.registerCustomerRequestDataV2 = registerCustomerRequestDataV2;
    }
}





