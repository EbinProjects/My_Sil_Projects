package com.softland.demo.Utils;
import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import com.google.gson.Gson;
import com.softland.demo.Annotations.Preferences;

/**
     * used to write files,shared preferences, and logs
     */
    public class FileUtils {

        /**
         * used to write preference file
         * you can pass any data type to this method
         *
         * @param context
         * @param preferenceName name of the preference file
         * @param keyName        key name of the value
         * @param value          value
         */
        public static void setPreference(Context context, String preferenceName, String keyName, Object value) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            if (value instanceof Integer) {
                editor.putInt(keyName, ((Integer) value).intValue());
            } else if (value instanceof String) {
                editor.putString(keyName, value.toString());
            } else if (value instanceof Boolean) {
                editor.putBoolean(keyName, ((Boolean) value).booleanValue());
            } else if (value instanceof Long) {
                editor.putLong(keyName, ((Long) value).longValue());
            }
            editor.apply();
        }

        /**
         * get string value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static String getPreferenceString(Context context, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(Preferences.CUSTOMER_PREFERENCE, Context.MODE_PRIVATE);
            return preferences.getString(keyName, "");
        }

        /**
         * get string value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static String getPreferenceString(Context context, String prefernceName, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(prefernceName, Context.MODE_PRIVATE);
            return preferences.getString(keyName, "");
        }

        /**
         * get integer value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static int getPreferenceInt(Context context, String preferenceName, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getInt(keyName, 0);
        }

        /**
         * get integer value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static int getPreferenceInt(Context context, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(Preferences.CUSTOMER_PREFERENCE, Context.MODE_PRIVATE);
            return preferences.getInt(keyName, 0);
        }


        /**
         * get long value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static long getPreferenceLong(Context context, String keyName) {
            SharedPreferences preferences = context.getSharedPreferences(Preferences.CUSTOMER_PREFERENCE, Context.MODE_PRIVATE);
            return preferences.getLong(keyName, -1);
        }

        public static long getPreferenceLong(Context context,String preferenceName, String keyName,long defaultValue) {
            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getLong(keyName, defaultValue);
        }

        /**
         * get long value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static long getPreferenceLong(Context context, String preferenceName, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getLong(keyName, -1);
        }

        /**
         * get boolen value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static Boolean getPreferenceBoolean(Context context, String keyName) {

            SharedPreferences preferences = context.getSharedPreferences(Preferences.CUSTOMER_PREFERENCE, Context.MODE_PRIVATE);
            return preferences.getBoolean(keyName, false);
        }

        /**
         * get boolen value from prefernces
         *
         * @param context
         * @param keyName key name of the value
         * @return value of given key if no key  in preference return defalut value
         */
        public static Boolean getPreferenceBoolean(Context context, String preferenceName, String
                keyName) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getBoolean(keyName, false);
        }


        /**
         * get string value from preferences
         *
         * @param context
         * @param keyName key name of the value
         * @param defaultValue default value (if can't find a  specified value )
         * @return value of given key if no key  in preference return default value
         */
        public static String getPreferenceString(Context context, String prefernceName, String keyName, String defaultValue) {

            SharedPreferences preferences = context.getSharedPreferences(prefernceName, Context.MODE_PRIVATE);
            return preferences.getString(keyName, defaultValue);
        }

        public static boolean getPreferenceBoolean(Context context, String prefernceName, String keyName, boolean defaultValue) {

            SharedPreferences preferences = context.getSharedPreferences(prefernceName, Context.MODE_PRIVATE);
            return preferences.getBoolean(keyName, defaultValue);
        }


        /**
         * get integer value from preferences
         *
         * @param context
         * @param keyName key name of the value
         * @param defaultValue default value (if can't find a  specified value )
         * @return value of given key if no key  in preference return default value
         */
        public static int getPreferenceInt(Context context, String preferenceName, String keyName, int defaultValue) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getInt(keyName, defaultValue);
        }


        /**
         * get integer value from preferences
         *
         * @param context
         * @param keyName key name of the value
         * @param defaultValue default value (if can't find a  specified value )
         * @return value of given key if no key  in preference return default value
         */
        public static boolean getPreferenceBoolen(Context context, String preferenceName, String keyName, boolean defaultValue) {

            SharedPreferences preferences = context.getSharedPreferences(preferenceName, Context.MODE_PRIVATE);
            return preferences.getBoolean(keyName, defaultValue);
        }

        /**
         * write log about service request
         *
         * @param dataToService sending data to service
         * @param serviceName   service link
         */
        public static void showSendData(Object dataToService, String serviceName) {
            Log.e("serviceData", "serviceName :" + serviceName + ",  showJsonData: " + new Gson().toJson(dataToService));
        }

        /**
         * write log about service success response
         *
         * @param dataFromService receiving data to service
         * @param serviceName     service link
         */
        public static void showResponseData(Object dataFromService, String serviceName) {
            Log.e("serviceData", "serviceName :" + serviceName + ", showResponseData: " + new Gson().toJson(dataFromService));
        }


        /**
         * write log about service error response
         *
         * @param dataFromService receiving data to service
         * @param serviceName     service link
         */
        public static void showErrorData(Object dataFromService, String serviceName) {
            Log.e("serviceData", "serviceName :" + serviceName + ", showResponseData: " + new Gson().toJson(dataFromService));
        }

    }


