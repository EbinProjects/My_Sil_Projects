package com.softland.demo.UI;





import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.os.SystemClock;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.softland.demo.Annotations.ServiceNames;
import com.softland.demo.Annotations.ServiceResponseStatus;
import com.softland.demo.Interfaces.APIInterface;
import com.softland.demo.Interfaces.RetrofitApi;
import com.softland.demo.R;



import com.softland.demo.RetrofitModels.Credentials;
import com.softland.demo.RetrofitModels.GetAllCustomerForLoginRequest;
import com.softland.demo.RetrofitModels.GetAllCustomerForLoginRequestData;
import com.softland.demo.RetrofitModels.GetAllCustomerForLoginResponse;
import com.softland.demo.RetrofitModels.LoginCustomerRequestData_V2;
import com.softland.demo.RetrofitModels.LoginCustomerRequest_V2;
import com.softland.demo.RetrofitModels.LoginCustomerResponse_V2;
import com.softland.demo.Utils.FileUtils;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    private Spinner spinner;

    EditText etUsername;
    EditText etPassword;
    Button Login;
    TextView signup;
    ProgressDialog progressDialog;
    // UserService userService;
    APIInterface authenticationInterface;
    private static final String TAG = "MainActivity";
    private long mLastClickTime;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etUsername = (EditText) findViewById(R.id.usernameid);
        etPassword = (EditText) findViewById(R.id.passwodid);
        Login = (Button) findViewById(R.id.logid);
        signup=(TextView)findViewById(R.id.signupId);
        // userService = ApiUtils.getUserService();
        spinner=(Spinner)findViewById(R.id.spinner1);






       ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.Languages, android.R.layout.simple_spinner_item);
       adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
       spinner.setAdapter(adapter);
       spinner.setOnItemSelectedListener(this);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(MainActivity.this, SignUp.class);
                startActivity(intent);

            }
        });




        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                if (SystemClock.elapsedRealtime() - mLastClickTime < 1000){
                    return;
                }
                mLastClickTime = SystemClock.elapsedRealtime();


                String username = etUsername.getText().toString();
                String password = etPassword.getText().toString();

                //validate form
                if (validateLogin(username,password)) {
                    //do login
                    getAllCustomerForLogin(username,password,1);

                }
            }
        });

    }



    private boolean validateLogin(String username, String password) {
        if (username == null || username.trim().length() == 0) {
            Toast.makeText(this, "Username is required", Toast.LENGTH_SHORT).show();
            return false;
        }
        if (password == null || password.trim().length() == 0) {
            Toast.makeText(this, "Password is required", Toast.LENGTH_SHORT).show();
            return false;

        }


        return true;
    }










  /*  private void loginCustomer(final String username,final String password){
        Call call = userService.Login(username,password);
       call.enqueue(new Callback() {
            @Override
            public void onResponse(Call call, Response response) {
                if(response.isSuccessful()){
                   LoginCustomerRequestData_V2 Obj =  response.body();
                    if(Obj.getMessage().equals("true")){
                        //login start main activity


                    } else {
                        Toast.makeText(MainActivity.this, "The username or password is incorrect", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Error! Please try again!", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call call, Throwable t) {
                Toast.makeText(MainActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });*/




    public void loginCustomer(final String username, final String password, final int customerId, int isDevice) {


        if (authenticationInterface == null) {
            String baseUrl ="http://202.88.237.210/RMS%20BYKYCUST_API_AUTHENTICATION/api/AuthenticationController/";
            authenticationInterface = RetrofitApi.getAuthClient(baseUrl).create(APIInterface.class);
        }


        Credentials credentials = new Credentials("9.1636853","9.1636853","0.0","854b39a86c55b9dd","869372039525012","1.0.40","android : 8.1.0 : O_MR1 :","CPH1803",
                0,"LoginCustomer","0","",0,0,0,"");

        LoginCustomerRequestData_V2 loginCustomerRequestDataV2 = new LoginCustomerRequestData_V2(username, password, customerId, isDevice);
        LoginCustomerRequest_V2 loginCustomerRequestV2 = new LoginCustomerRequest_V2(credentials, loginCustomerRequestDataV2);


        Log.e(TAG, "calling api loginCustomer.");
        FileUtils.showSendData(authenticationInterface.loginCustomerV2(loginCustomerRequestV2).request().url().toString(), ServiceNames.LOGIN_CUSTOMER_V2);
        FileUtils.showSendData(loginCustomerRequestV2, ServiceNames.LOGIN_CUSTOMER_V2);


        Call<LoginCustomerResponse_V2> loginResponseCall = authenticationInterface.loginCustomerV2(loginCustomerRequestV2);
        loginResponseCall.enqueue(new Callback<LoginCustomerResponse_V2>() {

            @Override
            public void onResponse(Call<LoginCustomerResponse_V2> call, Response<LoginCustomerResponse_V2> response) {


                try {
                    FileUtils.showResponseData(response.body()
                            , ServiceNames.LOGIN_CUSTOMER_V2);
                    if (response.body().getLoginCustomerStatusReturnV2() != null) {
                        Log.e(TAG, "loginCustomer, api calling is success: " +
                                response.body().getLoginCustomerStatusReturnV2().getStatus());

                        if (response.body().getLoginCustomerStatusReturnV2().getStatus()
                                .equals(ServiceResponseStatus.SUCCESS_CODE)) {

                            progressDialog=new ProgressDialog(MainActivity.this);
                            progressDialog.show();
                            progressDialog.setContentView(R.layout.progress_dialog);
                            progressDialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);



                            Intent intent = new Intent(MainActivity.this, FirstPage.class);
                            intent.putExtra("message",response.body().getLoginCustomerResponseDataV2().getMessage());
                            intent.putExtra("name", response.body().getLoginCustomerResponseDataV2().getCustomerName());
                            intent.putExtra("ZoneID",response.body().getLoginCustomerResponseDataV2().getZoneID());
                            intent.putExtra("PhoneNumber",response.body().getLoginCustomerResponseDataV2().getPhoneNumber());
                            startActivity(intent);











                /*     }
                         else {
                            //Api execution error.
                            apiCallbackListener.onSuccess(response.body().getLoginCustomerStatusReturnV2());

                        }
                    } else {
                        //empty response error
                        apiCallbackListener.onSuccess(null);

                    }
                } catch (
                        Exception e) {
                    //unknown error.
                    e.printStackTrace();
                    apiCallbackListener.onSuccess(null);
                }

                 */
                        } else {
                             Toast.makeText(MainActivity.this, response.body().getLoginCustomerStatusReturnV2().getMessage(), Toast.LENGTH_SHORT).show();
                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<LoginCustomerResponse_V2> call, Throwable t) {

                //api calling error.
                Log.e(TAG, "loginCustomer, api calling is failed: " + t.getMessage());
                FileUtils.showErrorData(t.getMessage(), ServiceNames.LOGIN_CUSTOMER_V2);


            }
        });
    }


    public void getAllCustomerForLogin(final String username, final String password, final int isDevice) {



        if (authenticationInterface == null) {
            String baseUrl = "http://202.88.237.210/RMS%20BYKYCUST_API_AUTHENTICATION/api/AuthenticationController/";
            authenticationInterface = RetrofitApi.getAuthClient(baseUrl).create(APIInterface.class);
        }

        Credentials credentials = new Credentials("9.1636853","9.1636853","0.0","854b39a86c55b9dd","869372039525012","1.0.40","android : 8.1.0 : O_MR1 :","CPH1803",
                0,"LoginCustomer","0","",0,0,0,"");

        GetAllCustomerForLoginRequestData getAllCustomerForLoginRequestData = new GetAllCustomerForLoginRequestData(username, password,isDevice);
        GetAllCustomerForLoginRequest getAllCustomerForLoginRequest = new GetAllCustomerForLoginRequest(credentials, getAllCustomerForLoginRequestData);


        Log.e(TAG, "calling api getAllCustomerForLogin.");
        FileUtils.showSendData(authenticationInterface.getAllCustomerForLogin(getAllCustomerForLoginRequest).request().url().toString(), ServiceNames.GET_ALL_CUSTOMER_FOR_LOGIN);
        FileUtils.showSendData(getAllCustomerForLoginRequest, ServiceNames.GET_ALL_CUSTOMER_FOR_LOGIN);



        Call<GetAllCustomerForLoginResponse> getAllCustomerForLoginResponseCall = authenticationInterface.getAllCustomerForLogin(getAllCustomerForLoginRequest);
        getAllCustomerForLoginResponseCall.enqueue(new Callback<GetAllCustomerForLoginResponse>() {

            @Override
            public void onResponse(Call<GetAllCustomerForLoginResponse> call, Response<GetAllCustomerForLoginResponse> response) {


                try {
                    FileUtils.showResponseData(response.body()
                            , ServiceNames.GET_ALL_CUSTOMER_FOR_LOGIN);
                    if (response.body().getStatusReturn() != null) {
                        Log.e(TAG, "loginCustomer, api calling is success: " +
                                response.body().getStatusReturn().getStatus());

                        if (response.body().getGetAllCustomerForLoginResponseData().get(0).getRetStatus()
                                .equals(ServiceResponseStatus.SUCCESS_CODE)) {
                            loginCustomer(username,password,
                                    response.body().getGetAllCustomerForLoginResponseData().get(0).getCustomerID()
                                    ,isDevice);


                            Toast.makeText(MainActivity.this, response.body().getStatusReturn().getMessage(), Toast.LENGTH_SHORT).show();






                        /*     }
                         else {
                            //Api execution error.
                            apiCallbackListener.onSuccess(response.body().getLoginCustomerStatusReturnV2());

                        }
                    } else {
                        //empty response error
                        apiCallbackListener.onSuccess(null);

                    }
                } catch (
                        Exception e) {
                    //unknown error.
                    e.printStackTrace();
                    apiCallbackListener.onSuccess(null);
                }
                 */
                        } else {
                            Toast.makeText(MainActivity.this,"Invalid User",Toast.LENGTH_SHORT).show();                        }

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }

            @Override
            public void onFailure(Call<GetAllCustomerForLoginResponse> call, Throwable t) {

                //api calling error.
                Log.e(TAG, "loginCustomer, api calling is failed: " + t.getMessage());
                FileUtils.showErrorData(t.getMessage(), ServiceNames.GET_ALL_CUSTOMER_FOR_LOGIN);


            }
        });
    }


    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String text = parent.getItemAtPosition(position).toString();
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}
