package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginCustomerRequest_V2 {

    @SerializedName("Credentials")
    @Expose
    private Credentials credentials;
    @SerializedName("RequestData")
    @Expose
    private LoginCustomerRequestData_V2 loginCustomerRequestDataV2;


    public LoginCustomerRequest_V2(Credentials credentials, LoginCustomerRequestData_V2 loginCustomerRequestDataV2) {
        this.credentials = credentials;
        this.loginCustomerRequestDataV2 = loginCustomerRequestDataV2;
    }


    public Credentials getCredentials() {
        return credentials;
    }

    public void setCredentials(Credentials credentials) {
        this.credentials = credentials;
    }

    public LoginCustomerRequestData_V2 getLoginCustomerRequestDataV2() {
        return loginCustomerRequestDataV2;
    }

    public void setLoginCustomerRequestDataV2(LoginCustomerRequestData_V2 loginCustomerRequestDataV2) {
        this.loginCustomerRequestDataV2 = loginCustomerRequestDataV2;
    }
}
