package com.softland.demo.RetrofitModels;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class LoginCustomerResponseData_V2 {

    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("RetStatus")
    @Expose
    private Integer retStatus;
    @SerializedName("ZoneID")
    @Expose
    private Integer zoneID;
    @SerializedName("CustomerID")
    @Expose
    private Integer customerID;
    @SerializedName("CustomerName")
    @Expose
    private String customerName;
    @SerializedName("CustomerCode")
    @Expose
    private String customerCode;
    @SerializedName("PhoneNumber")
    @Expose
    private String phoneNumber;
    @SerializedName("MailID")
    @Expose
    private String mailID;

    @SerializedName("Address")
    @Expose
    private String address;

    @SerializedName("ShortCode")
    @Expose
    private String shortCode;

    @SerializedName("TokenID")
    @Expose
    private String tokenId;

    public LoginCustomerResponseData_V2() {

    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getRetStatus() {
        return retStatus;
    }

    public void setRetStatus(Integer retStatus) {
        this.retStatus = retStatus;
    }

    public Integer getZoneID() {
        return zoneID;
    }

    public void setZoneID(Integer zoneID) {
        this.zoneID = zoneID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        this.customerID = customerID;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getCustomerCode() {
        return customerCode;
    }

    public void setCustomerCode(String customerCode) {
        this.customerCode = customerCode;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getMailID() {
        return mailID;
    }

    public void setMailID(String mailID) {
        this.mailID = mailID;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }

    public String getTokenId() {
        return tokenId;
    }

    public void setTokenId(String tokenId) {
        this.tokenId = tokenId;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }


}
