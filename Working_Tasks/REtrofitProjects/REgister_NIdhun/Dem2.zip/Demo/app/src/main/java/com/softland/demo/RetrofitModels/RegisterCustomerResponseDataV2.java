package com.softland.demo.RetrofitModels;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class RegisterCustomerResponseDataV2 {
    @SerializedName("Message")
    @Expose
    private String message;
    @SerializedName("RetStatus")
    @Expose
    private Integer retStatus;

    public RegisterCustomerResponseDataV2(String message, Integer retStatus) {
        this.message = message;
        this.retStatus = retStatus;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Integer getRetStatus() {
        return retStatus;
    }

    public void setRetStatus(Integer retStatus) {
        this.retStatus = retStatus;
    }
}
