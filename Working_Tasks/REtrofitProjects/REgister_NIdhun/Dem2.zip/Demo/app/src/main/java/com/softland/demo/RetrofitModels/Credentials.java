

package com.softland.demo.RetrofitModels;

import android.content.Context;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

/**
 * Common Data that send to web in all services
 */
public class Credentials {


    @SerializedName("Latitude")
    @Expose
    private String latitude;

    @SerializedName("Longitude")
    @Expose
    private String longitude;
    @SerializedName("Altitude")
    @Expose
    private String altitude;
    @SerializedName("DeviceID")
    @Expose
    private String deviceID;
    @SerializedName("IMEI")
    @Expose
    private String iMEI;
    @SerializedName("APKVersion")
    @Expose
    private String aPKVersion;
    @SerializedName("AndroidVersion")
    @Expose
    private String androidVersion;
    @SerializedName("DeviceName")
    @Expose
    private String deviceName;
    @SerializedName("UserID")
    @Expose
    private Integer userID;
    @SerializedName("ServiceName")
    @Expose
    private String serviceName;
    @SerializedName("TokenID")
    @Expose
    private String tokenID;
    @SerializedName("BluetoothID")
    @Expose
    private String bluetoothID;
    @SerializedName("IsZipped")
    @Expose
    private Integer isZipped;
    @SerializedName("ZoneID")
    @Expose
    private Integer zoneID;
    @SerializedName("ZoneCode")
    @Expose
    private String zoneCode;
    @SerializedName("CustomerID")
    @Expose
    private Integer customerID;
    @SerializedName("ShortCode")
    @Expose
    private String shortCode;
    @SerializedName("DeviceNotificationID")
    @Expose
    private String deviceNotificationID;
    @SerializedName("DeviceType")
    @Expose
    private String deviceType;

    @Expose(serialize = false, deserialize = false)
    private transient Context context;




    public Credentials(String latitude, String longitude, String altitude, String deviceID, String iMEI,
                       String aPKVersion, String androidVersion, String deviceName, Integer userID, String serviceName,
                       String tokenID, String bluetoothID, Integer isZipped, Integer zoneID, Integer customerID, String shortCode) {
        super();
        this.latitude = latitude;
        this.longitude = longitude;
        this.altitude = altitude;
        this.deviceID = deviceID;
        this.iMEI = iMEI;
        this.aPKVersion = aPKVersion;
        this.androidVersion = androidVersion;
        this.deviceName = deviceName;
        this.userID = userID;
        this.serviceName = serviceName;
        this.tokenID = tokenID;
        this.bluetoothID = bluetoothID;
        this.isZipped = isZipped;
        this.zoneID = zoneID;
        this.customerID = customerID;
        this.shortCode = shortCode;
    }

    public String getDeviceNotificationID() {
        return deviceNotificationID;
    }

    public void setDeviceNotificationID(String deviceNotificationID) {
        this.deviceNotificationID = deviceNotificationID;
    }

    public String getZoneCode() {
        return zoneCode;
    }

    public void setZoneCode(String zoneCode) {
        this.zoneCode = zoneCode;
    }

    public String getDeviceType() {
        return deviceType;
    }

    public void setDeviceType(String deviceType) {
        this.deviceType = deviceType;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongitude() {
        return longitude;
    }

    public void setLongitude(String longitude) {
        this.longitude = longitude;
    }

    public String getAltitude() {
        return altitude;
    }

    public void setAltitude(String altitude) {
        this.altitude = altitude;
    }

    public String getDeviceID() {
        return deviceID;
    }

    public void setDeviceID(String deviceID) {
        this.deviceID = deviceID;
    }

    public String getIMEI() {
        return iMEI;
    }

    public void setIMEI(String iMEI) {
        this.iMEI = iMEI;
    }

    public String getAPKVersion() {
        return aPKVersion;
    }

    public void setAPKVersion(String aPKVersion) {
        this.aPKVersion = aPKVersion;
    }

    public String getAndroidVersion() {
        return androidVersion;
    }

    public void setAndroidVersion(String androidVersion) {
        this.androidVersion = androidVersion;
    }

    public String getDeviceName() {
        return deviceName;
    }

    public void setDeviceName(String deviceName) {
        this.deviceName = deviceName;
    }

    public Integer getUserID() {
        return userID;
    }

    public void setUserID(Integer userID) {
        this.userID = userID;
    }

    public String getServiceName() {
        return serviceName;
    }

    public void setServiceName(String serviceName) {
        this.serviceName = serviceName;
    }

    public String getTokenID() {
        return tokenID;
    }

    public void setTokenID(String tokenID) {
        this.tokenID = tokenID;
    }

    public String getBluetoothID() {
        return bluetoothID;
    }

    public void setBluetoothID(String bluetoothID) {
        this.bluetoothID = bluetoothID;
    }

    public Integer getIsZipped() {
        return isZipped;
    }

    public void setIsZipped(Integer isZipped) {
        this.isZipped = isZipped;
    }

    public Integer getZoneID() {
        return zoneID;
    }

    public void setZoneID(Integer zoneID) {
        this.zoneID = zoneID;
    }

    public Integer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Integer customerID) {
        this.customerID = customerID;
    }

    public String getShortCode() {
        return shortCode;
    }

    public void setShortCode(String shortCode) {
        this.shortCode = shortCode;
    }


    public String getiMEI() {
        return iMEI;
    }

    public void setiMEI(String iMEI) {
        this.iMEI = iMEI;
    }

    public String getaPKVersion() {
        return aPKVersion;
    }

    public void setaPKVersion(String aPKVersion) {
        this.aPKVersion = aPKVersion;
    }

    public Context getContext() {
        return context;
    }

    public void setContext(Context context) {
        this.context = context;
    }
}

