package com.softland.demo.Interfaces;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.util.concurrent.TimeUnit;

import okhttp3.OkHttpClient;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitApi {

    private static Retrofit retrofit = null;
    private static Retrofit retrofitAuth = null;
    private static Retrofit retrofitinit = null;
    private static Retrofit retrofitReport = null;
    public static int ServiceCounter = 0;
    public static int TIME_OUT = 500;//default value is 500.( some case using 19709).
    //not using.(for hard coded service calling)
    //public static String BASE_URL = "http://202.88.237.210/";
    //public static String BASE_URL = "http://94.207.40.172:2030/";
    public static String BASE_URL = "http://202.88.237.210/";

    public static String GetServicelink = "http://androservice.softlandindia.co.in/SILService.svc/";


    public static void LoadURL() {
        switch (ServiceCounter) {
            case 0:
                GetServicelink = "http://androservice.softlandindia.co.in/SILService.svc/";
                break;
            case 1:
                GetServicelink = "http://androservice.palmtecandro.com/SILService.svc/";
                break;
            case 2:
                GetServicelink = "http://androservice.softlandindiasalesforce.com/SILService.svc/";
                break;
            case 3:
                GetServicelink = "http://androservice.salesforceautomation.in/SILService.svc/";
                break;
            case 4:
                GetServicelink = "http://androservice.softlandsalesforce.com/SILService.svc/";
                break;
            default:
                ServiceCounter = 0;
                GetServicelink = "";
                break;
        }

    }


    //for hard coded service calling.
    public static Retrofit getServiceFromHardcodedUrl() {

        OkHttpClient longTimeOutHttpClient = new OkHttpClient.Builder()
                .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                .build();
        /* if (retrofit == null) {*/
        retrofit = new retrofit2.Retrofit.Builder()
                //.baseUrl(GetServicelink)
                .baseUrl(BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        //}
        return retrofit;
    }


    /**
     * Create retrofit object
     *
     * @return retrofit object(Singleton)
     */
    public static Retrofit getService() {

        Gson gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .create();

        OkHttpClient longTimeOutHttpClient = new OkHttpClient.Builder()
                .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                .build();
        if (retrofit == null) {
            retrofit = new retrofit2.Retrofit.Builder()
                    .baseUrl(GetServicelink)
                    .client(longTimeOutHttpClient)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;
    }

    public static Retrofit getAuthClient(String baseUrl) {
        if (retrofitAuth == null) {
            retrofitAuth = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofitAuth;
    }

    public static Retrofit getRetrofitReport(String baseUrl) {
        if (retrofitReport == null) {
            retrofitReport = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .addConverterFactory(GsonConverterFactory.create())
                    .build();
        }
        return retrofitReport;
    }




    public static Retrofit getClient(String baseUrl) {

        Gson gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .create();

        OkHttpClient longTimeOutHttpClient = new OkHttpClient.Builder()
                .readTimeout(TIME_OUT, TimeUnit.SECONDS)
                .connectTimeout(TIME_OUT, TimeUnit.SECONDS)
                .build();
        if (retrofit == null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(baseUrl)
                    .client(longTimeOutHttpClient)
                    .addConverterFactory(GsonConverterFactory.create(gson))
                    .build();
        }
        return retrofit;
    }


    /**
     * Use this client only for initial fetchUrl service only
     *
     * @return
     */
    public static Retrofit getinitClient() {

        Gson gson = new GsonBuilder()
                .excludeFieldsWithoutExposeAnnotation()
                .create();

        retrofitinit = new Retrofit.Builder()
                .baseUrl(GetServicelink)
                .addConverterFactory( GsonConverterFactory.create(gson))
                .build();
        return retrofitinit;

    }

}
