package com.softland.sollite;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class ResultAdapter extends RecyclerView.Adapter<ResultAdapter.ResultViewHolder> {
    private Context context;
    List<DataModelItem> pdflist;

    public ResultAdapter(MainActivity firstActivity, List<DataModelItem> pdfLists) {
        pdflist = pdfLists;
        context=firstActivity;
    }


    @Override
    public ResultViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.data_collection, parent, false);
        return new ResultViewHolder(view);
    }


    @Override
    public void onBindViewHolder(ResultViewHolder holder, int position) {
        DataModelItem p = pdflist.get(position);
        holder.OrderName.setText(p.getOrderNumber());
        holder.OrderDate.setText(p.getOrderDate());
        holder.NoofItem.setText(String.valueOf(p.getNoOfItems()));
        holder.NoOfFree.setText(String.valueOf(p.getNoOfFreeItems()));
        holder.Remark.setText(p.getRemarks());
        holder.orderAmound.setText(String.valueOf(p.getOrderAmount()));
        holder.orderStatus.setText(String.valueOf(p.getOrderStatus()));


//        try {
//            holder.CataID.getBytes(products.getCategory_id());
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }
//        try {
//            holder.barcode.getBytes(products.getBarcodeNumber());
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }
//        try {
//            holder.ProductCode.getBytes(products.getProduct_code());
//        } catch (UnsupportedEncodingException e) {
//            e.printStackTrace();
//        }


    }

    @Override
    public int getItemCount() {
        return pdflist.size();
    }

    class ResultViewHolder extends RecyclerView.ViewHolder {

        TextView OrderName,OrderDate,NoofItem,NoOfFree,orderAmound,orderStatus,Remark;


        public ResultViewHolder(View itemView) {
            super(itemView);
            this.OrderName = itemView.findViewById(R.id.orderNAme);
            this.OrderDate = itemView.findViewById(R.id.orderDate);
            this.NoofItem = itemView.findViewById(R.id.No_of_Item);
            this.NoOfFree = itemView.findViewById(R.id.FreeItem);
            this.orderAmound = itemView.findViewById(R.id.orderAmmount);
            this.orderStatus = itemView.findViewById(R.id.OrderStatus);
            this.Remark = itemView.findViewById(R.id.Remark);
//            itemView.setOnClickListener(this);

        }

//        @Override
//        public void onClick(View view) {
//            Responses PDFs = pdflist.get(getAdapterPosition());
//            String data=PDFs.getFileLink();
//
//            Intent intent = new Intent(context, WebViewActivity.class);
//            intent.putExtra("tasks", data);
//
//            context.startActivity(intent);
//        }
    }
}
