package com.softland.sollite;

import com.google.gson.annotations.SerializedName;

public class DataModelItem{

	@SerializedName("OrderStatus")
	private int orderStatus;

	@SerializedName("NoOfFreeItems")
	private int noOfFreeItems;

	@SerializedName("Remarks")
	private String remarks;

	@SerializedName("NoOfItems")
	private int noOfItems;

	@SerializedName("OrderAmount")
	private double orderAmount;

	@SerializedName("OrderNumber")
	private String orderNumber;

	@SerializedName("OrderDate")
	private String orderDate;

	public DataModelItem(int orderStatus, int noOfFreeItems, String remarks, int noOfItems, double orderAmount, String orderNumber, String orderDate) {
		this.orderStatus = orderStatus;
		this.noOfFreeItems = noOfFreeItems;
		this.remarks = remarks;
		this.noOfItems = noOfItems;
		this.orderAmount = orderAmount;
		this.orderNumber = orderNumber;
		this.orderDate = orderDate;
	}

	public int getOrderStatus(){
		return orderStatus;
	}

	public int getNoOfFreeItems(){
		return noOfFreeItems;
	}

	public String getRemarks(){
		return remarks;
	}

	public int getNoOfItems(){
		return noOfItems;
	}

	public double getOrderAmount(){
		return orderAmount;
	}

	public String getOrderNumber(){
		return orderNumber;
	}

	public String getOrderDate(){
		return orderDate;
	}
}