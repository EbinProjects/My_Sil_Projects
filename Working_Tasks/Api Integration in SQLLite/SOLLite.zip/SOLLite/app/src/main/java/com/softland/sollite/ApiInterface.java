package com.softland.sollite;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiInterface {
    @GET("/p/")
    Call<List<DataModelItem>> getPDFs();
}
