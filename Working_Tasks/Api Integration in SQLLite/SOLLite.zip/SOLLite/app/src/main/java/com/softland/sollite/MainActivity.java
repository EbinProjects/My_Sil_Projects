package com.softland.sollite;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    ProgressBar progressBar;
    ResultAdapter resultAdapter;
    List<DataModelItem> pdfLists=new ArrayList<>();
    DBHelper myDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        recyclerView =findViewById(R.id.cycle);
        progressBar=findViewById(R.id.idLoadingPB);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        resultAdapter=new ResultAdapter(MainActivity.this,pdfLists);
        recyclerView.setAdapter(resultAdapter);
        myDb=new DBHelper(this);
        fetchPosts();
    }

    private void fetchPosts() {
        progressBar.setVisibility(View.VISIBLE);
        retrofitClient.getRetrofit().getPDFs().enqueue(new Callback<List<DataModelItem>>() {
            @Override
            public void onResponse(Call<List<DataModelItem>> call, Response<List<DataModelItem>> response) {
                if (response.isSuccessful()&&response.body()!=null){
                    List<DataModelItem> dataModelItem=  response.body();

//                    String number=dataModelItem.getOrderNumber();
//                    String date=dataModelItem.getOrderDate();
//                    int item=dataModelItem.getNoOfItems();
//                    int freeItem=dataModelItem.getNoOfFreeItems();
//                 double ammount=dataModelItem.getOrderAmount();
//                    int status=dataModelItem.getOrderStatus();
//                    String remark=dataModelItem.getRemarks();
//                    myDb.insertContact(number,date,item,freeItem,ammount,status,remark);

                    pdfLists.clear();
                    pdfLists.addAll(dataModelItem);
                    for (int i=0;i<pdfLists.size();i++){
                        String number=pdfLists.get(i).getOrderNumber();
                        String date=pdfLists.get(i).getOrderDate();
                       String item=String.valueOf(pdfLists.get(i).getNoOfItems());
                        String freeItem=String.valueOf(pdfLists.get(i).getNoOfFreeItems());
                        String ammount=String.valueOf(pdfLists.get(i).getOrderAmount());
                        String status=String.valueOf(pdfLists.get(i).getOrderStatus());
                        String remark=pdfLists.get(i).getRemarks();
                        myDb.insertContact(number,date,item,freeItem,ammount,status,remark);

                    }

                    Log.d("file", "fdki: "+response.body());

                    resultAdapter.notifyDataSetChanged();
                    progressBar.setVisibility(View.GONE);

                }
            }

            @Override
            public void onFailure(Call<List<DataModelItem>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                Toast.makeText(getApplicationContext(), "Errrrrooroeoro"+t.getMessage().toString(), Toast.LENGTH_SHORT).show();
            }
        });
    }
}