package com.softland.sollite;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.HashMap;

public class DBHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "MyDBName.db";
    public static final String STOCK_TABLE_NAME = "Stocks";
    public static final String STOCK_COLUMN_ID = "id";
    public static final String ORDER_NUMBER = "OrderNumber";
    public static final String ORDER_DATE = "orderDate";
    public static final String NO_OF_ITEMS = "items";
    public static final String NO_FREE_ITEMS = "freeItems";
    public static final String ORDER_AMMOUNT = "amount";
    public static final String ORDER_STATUS = "status";
    public static final String ORDER_REMARK = "Remarks";
    private HashMap hp;

    public DBHelper(Context context) {
        super(context, DATABASE_NAME , null, 2);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // TODO Auto-generated method stub
        db.execSQL(
                "create table Stocks (id integer primary key, OrderNumber text,orderDate text,items text, freeItems text,amount text,status text,Remarks text)"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // TODO Auto-generated method stub
        db.execSQL("DROP TABLE IF EXISTS Stocks");
        onCreate(db);
    }

    public boolean insertContact (String number, String date, String item, String freeitem,String ammount,String status,String remark) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put("OrderNumber", number);
        contentValues.put("orderDate", date);
        contentValues.put("items", item);
        contentValues.put("freeItems", freeitem);
        contentValues.put("amount", ammount);
        contentValues.put("status", status);
        contentValues.put("Remarks", remark);
        db.insert("Stocks", null, contentValues);
        return true;
    }

//    public Cursor getData(int id) {
//        SQLiteDatabase db = this.getReadableDatabase();
//        Cursor res =  db.rawQuery( "select * from contacts where id="+id+"", null );
//        return res;
//    }

//    public int numberOfRows(){
//        SQLiteDatabase db = this.getReadableDatabase();
//        int numRows = (int) DatabaseUtils.queryNumEntries(db, CONTACTS_TABLE_NAME);
//        return numRows;
//    }
//
//    public boolean updateContact (Integer id, String name, String phone, String email, String street,String place) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        ContentValues contentValues = new ContentValues();
//        contentValues.put("name", name);
//        contentValues.put("phone", phone);
//        contentValues.put("email", email);
//        contentValues.put("street", street);
//        contentValues.put("place", place);
//        db.update("contacts", contentValues, "id = ? ", new String[] { Integer.toString(id) } );
//        return true;
//    }
//
//    public Integer deleteContact (Integer id) {
//        SQLiteDatabase db = this.getWritableDatabase();
//        return db.delete("contacts",
//                "id = ? ",
//                new String[] { Integer.toString(id) });
//    }

    @SuppressLint("Range")
    public ArrayList<DataModelItem> getAllCotacts() {
        ArrayList<DataModelItem> array_list = new ArrayList<DataModelItem>();

        //hp = new HashMap();
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor res =  db.rawQuery( "select * from Stocks", null );
        res.moveToFirst();

        while(res.isAfterLast() == false){
//            array_list.add(new DataModelItem(res.getColumnIndex(ORDER_NUMBER),res.getColumnIndex(ORDER_DATE),res.getString(res.getColumnIndex(NO_OF_ITEMS)),res.getColumnIndex(NO_FREE_ITEMS),res.getColumnIndex(ORDER_AMMOUNT),res.getString(res.getColumnIndex(ORDER_STATUS)),res.getString(res.getColumnIndex(ORDER_REMARK)));
            res.moveToNext();
        }
        return array_list;
    }
}
