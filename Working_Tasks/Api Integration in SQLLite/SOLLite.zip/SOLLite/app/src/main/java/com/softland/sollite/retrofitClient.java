package com.softland.sollite;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class retrofitClient {
    private static Retrofit retrofit=null;
    public static ApiInterface getRetrofit(){
        if (retrofit==null)
            retrofit=new Retrofit.Builder().baseUrl("http://d946-202-88-237-210.ngrok.io").addConverterFactory(GsonConverterFactory.create()).build();
        return retrofit.create(ApiInterface.class);
    }
}
