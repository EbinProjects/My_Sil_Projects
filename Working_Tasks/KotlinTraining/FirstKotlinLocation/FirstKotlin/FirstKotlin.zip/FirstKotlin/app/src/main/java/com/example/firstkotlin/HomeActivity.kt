package com.example.firstkotlin

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.google.android.material.tabs.TabLayout
import kotlinx.android.synthetic.main.activity_home.*

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_home)
        tbLayout!!.addTab(tbLayout!!.newTab().setText("Tab 1"))
        tbLayout!!.addTab(tbLayout!!.newTab().setText("Tab 2"))
        tbLayout!!.addTab(tbLayout!!.newTab().setText("Tab 3"))
        tbLayout!!.tabGravity=TabLayout.GRAVITY_FILL
    }
}