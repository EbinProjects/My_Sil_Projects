package com.example.firstkotlin

class MyAdapter {
}