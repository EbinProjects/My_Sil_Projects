package com.example.firstkotlin.fragments

import android.annotation.SuppressLint
import android.app.Activity.RESULT_OK
import android.app.AlertDialog
import android.content.DialogInterface
import android.content.Intent
import android.database.Cursor
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import com.example.firstkotlin.R
import kotlinx.android.synthetic.main.fragment_profile.*
import java.io.ByteArrayOutputStream


class ProfileFragment: Fragment(), View.OnClickListener {
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?): View? {
        return inflater!!.inflate(R.layout.fragment_profile,container,false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tvUploadImage.setOnClickListener(this)
        tvCurrentLocation.setOnClickListener(this)
        tvShowLocation.setOnClickListener(this)
    }

    private fun selectImage() {
        val options = arrayOf<CharSequence>("Take Photo", "Choose from Gallery", "Cancel")
        val builder: AlertDialog.Builder = AlertDialog.Builder(requireActivity())
        builder.setTitle("Add Photo!")
        builder.setItems(options, DialogInterface.OnClickListener { dialog, item ->
            if (options[item] == "Take Photo") {
                val cameraIntent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
                startActivityForResult(cameraIntent, 1)
            }
            else if (options[item].equals("Choose from Gallery"))
            {
                val intent =
                    Intent(Intent.ACTION_PICK)
                intent.type="image/*"
                startActivityForResult(intent, 2)
            }
            else if (options[item].equals("Cancel")) {
                dialog.dismiss();
            }

        })
        builder.show()
    }

    override fun onClick(v: View?) {
when(v!!.id){
    R.id.tvUploadImage-> {
        selectImage()
    }
    R.id.tvCurrentLocation->{

    }
}
    }


    @SuppressLint("LongLogTag")
    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, dataq: Intent?) {
        super.onActivityResult(requestCode, resultCode, dataq)
        if (resultCode == RESULT_OK) {
            if (requestCode == 1) {
                val photo = dataq!!.extras!!["data"] as Bitmap?
                 ivImage.setImageBitmap(photo);
            }
//                var f = File(Environment.getExternalStorageDirectory().toString())
//                for (temp in f.listFiles()) {
//                    if (temp.name.equals("temp.jpg")) {
//                        f = temp
//                        break
//                    }
//                }
//                try {
//                    val bitmap: Bitmap
//                    val bitmapOptions = BitmapFactory.Options()
//                    bitmap = BitmapFactory.decodeFile(
//                        f.absolutePath,
//                        bitmapOptions
//                    )
//                    ivImage.setImageBitmap(bitmap)
//                    val path = (Environment
//                        .getExternalStorageDirectory()
//                        .toString() + File.separator
//                            + "Phoenix" + File.separator + "default")
//                    f.delete()
//                    var outFile: OutputStream? = null
//                    val file = File(path, System.currentTimeMillis().toString() + ".jpg")
//                    try {
//                        outFile = FileOutputStream(file)
//                        bitmap.compress(Bitmap.CompressFormat.JPEG, 85, outFile)
//                        outFile.flush()
//                        outFile.close()
//                    } catch (e: FileNotFoundException) {
//                        e.printStackTrace()
//                    } catch (e: IOException) {
//                        e.printStackTrace()
//                    } catch (e: Exception) {
//                        e.printStackTrace()
//                    }
//                } catch (e: Exception) {
//                    e.printStackTrace()
//                }
//            }
        }
        else if (requestCode == 2) {
            val selectedImage: Uri? = dataq?.data
            ivImage.setImageURI(selectedImage)


        }
        }

    private fun getRealPathFromURI(tempUri: Uri?): String {
        var path = ""
        if (requireActivity().getContentResolver() != null) {
            val cursor: Cursor? = tempUri?.let { requireActivity().getContentResolver().query(it, null, null, null, null) }
            if (cursor != null) {
                cursor.moveToFirst()
                val idx = cursor.getColumnIndex(MediaStore.Images.ImageColumns.DATA)
                path = cursor.getString(idx)
                cursor.close()
            }
        }
        return path


    }

    private fun getImageUri(requireActivity: FragmentActivity, photo: Bitmap?): Uri? {
        val bytes = ByteArrayOutputStream()
        photo?.compress(Bitmap.CompressFormat.JPEG, 100, bytes)
        val path: String = MediaStore.Images.Media.insertImage(
            requireActivity.getContentResolver(),
            photo,
            "Title",
            null
        )
        return Uri.parse(path)
    }
}


