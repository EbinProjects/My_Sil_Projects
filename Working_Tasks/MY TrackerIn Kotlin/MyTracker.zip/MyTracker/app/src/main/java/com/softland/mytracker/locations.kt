package com.softland.mytracker

 class locations(latt: Double, lot: Double) {
    var latti: Double = 0.0
        get() = field        // getter
        set(value) {         // setter
            field = value
        }
    var logiti: Double = 0.0
        get() = field        // getter
        set(value) {         // setter
            field = value
        }
}