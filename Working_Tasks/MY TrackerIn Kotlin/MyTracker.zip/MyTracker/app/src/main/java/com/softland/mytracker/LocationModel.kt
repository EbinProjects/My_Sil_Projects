package com.softland.mytracker

   data class LocationModel (val longittude:Double,val lattitude:Double){

   }
